# Ingestion test
This is harmless source data. ASE must not execute it.
