import { useState } from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { Shield, Cpu, Key, FileCode, CheckCircle, RefreshCw, Send, ArrowRightLeft, Activity } from 'lucide-react';
import {
  API,
  type OpenApiImportResponse,
  type ApiAuthTestResponse,
  type BenchmarkEvaluationResponse,
  type CrossToolCorrelationResponse,
  type NodeTransferResponse,
  type NodeReceiveResponse,
} from '../api';

const fieldClass = 'bg-slate-900 border border-slate-700 rounded-lg p-2.5 text-sm text-slate-200 focus:outline-none focus:border-indigo-500 w-full';
const buttonPrimary = 'bg-indigo-600 hover:bg-indigo-500 text-white font-medium text-sm px-4 py-2 rounded-lg transition-colors disabled:opacity-40';
const buttonSecondary = 'bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium text-sm px-4 py-2 rounded-lg border border-slate-700 transition-colors disabled:opacity-40';

export default function SecuritySuite() {
  const [activeTab, setActiveTab] = useState<'api_sec' | 'evaluation' | 'collaboration'>('api_sec');

  // Common data
  const { data: projects = [] } = useQuery({ queryKey: ['projects'], queryFn: API.getProjects });
  const [selectedProjectId, setSelectedProjectId] = useState<string>('');
  const { data: targets = [] } = useQuery({
    queryKey: ['targets', selectedProjectId],
    queryFn: () => API.getTargets(selectedProjectId),
    enabled: !!selectedProjectId,
  });
  const [selectedTargetId, setSelectedTargetId] = useState<string>('');

  // ----------------------------------------------------------------------
  // TAB 1: API Security (OpenAPI & BOLA/BFLA)
  // ----------------------------------------------------------------------
  const [openApiFile, setOpenApiFile] = useState<File | null>(null);
  const [parsedSpec, setParsedSpec] = useState<OpenApiImportResponse | null>(null);
  const [authTestResult, setAuthTestResult] = useState<ApiAuthTestResponse | null>(null);

  const importMutation = useMutation({
    mutationFn: (file: File) => API.importOpenApi(selectedProjectId, selectedTargetId, file),
    onSuccess: (data) => {
      setParsedSpec(data);
      alert(`Imported "${data.title}" v${data.version} with ${data.parsed_endpoints_count} endpoints.`);
    },
    onError: (err: any) => {
      alert(`OpenAPI Import Failed: ${err.response?.data?.detail || err.message}`);
    },
  });

  const runAuthTestMutation = useMutation({
    mutationFn: () => API.runApiAuthTest(selectedProjectId, selectedTargetId, parsedSpec?.spec_id),
    onSuccess: (data) => {
      setAuthTestResult(data);
    },
    onError: (err: any) => {
      alert(`Auth Test Failed: ${err.response?.data?.detail || err.message}`);
    },
  });

  // ----------------------------------------------------------------------
  // TAB 2: Benchmark Evaluation & Correlation
  // ----------------------------------------------------------------------
  const [benchmarkResult, setBenchmarkResult] = useState<BenchmarkEvaluationResponse | null>(null);
  const [correlationResult, setCorrelationResult] = useState<CrossToolCorrelationResponse | null>(null);

  const evalMutation = useMutation({
    mutationFn: (runMock: boolean) => API.runBenchmarkEvaluation(runMock),
    onSuccess: (data) => setBenchmarkResult(data),
    onError: (err: any) => alert(`Benchmark Failed: ${err.response?.data?.detail || err.message}`),
  });

  const correlationMutation = useMutation({
    mutationFn: (projId: string) => API.getCrossToolCorrelation(projId),
    onSuccess: (data) => setCorrelationResult(data),
    onError: (err: any) => alert(`Correlation Failed: ${err.response?.data?.detail || err.message}`),
  });

  // ----------------------------------------------------------------------
  // TAB 3: Node-to-Node Transfer & CIA+AA Evaluation
  // ----------------------------------------------------------------------
  const [payloadType, setPayloadType] = useState<string>('TEXT');
  const [textContent, setTextContent] = useState<string>('CONFIDENTIAL: Security audit findings and remediation hash.');
  const [sharedSecret, setSharedSecret] = useState<string>('ASE_SECURE_TRANSFER_SECRET_KEY_2026');
  const [transferResponse, setTransferResponse] = useState<NodeTransferResponse | null>(null);
  const [receiveResponse, setReceiveResponse] = useState<NodeReceiveResponse | null>(null);

  const sendMutation = useMutation({
    mutationFn: () =>
      API.sendNodeTransfer({
        recipient_node_id: 'NODE_B',
        payload_type: payloadType,
        content: textContent,
        shared_secret: sharedSecret,
      }),
    onSuccess: (data) => {
      setTransferResponse(data);
      setReceiveResponse(null);
    },
    onError: (err: any) => alert(`Transfer Error: ${err.response?.data?.detail || err.message}`),
  });

  const receiveMutation = useMutation({
    mutationFn: () => {
      if (!transferResponse?.package) throw new Error('No package sent yet');
      return API.receiveNodeTransfer({
        package: transferResponse.package,
        shared_secret: sharedSecret,
      });
    },
    onSuccess: (data) => setReceiveResponse(data),
    onError: (err: any) => alert(`Decryption Error: ${err.response?.data?.detail || err.message}`),
  });

  const { data: secEval, refetch: refetchSecEval } = useQuery({
    queryKey: ['security-evaluation'],
    queryFn: API.getSecurityEvaluation,
  });

  return (
    <div className="max-w-7xl mx-auto space-y-6 pb-16">
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-white flex items-center gap-3">
            <Shield className="text-indigo-400" size={32} />
            Security Engineering & Benchmark Suite
          </h2>
          <p className="text-sm text-slate-400 mt-1">
            API Authorization Testing (BOLA/BFLA), Benchmark & Cross-Tool Correlation, and 2-Node Authenticated Transfer with CIA+AA Evaluation.
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex bg-[#0F1523] p-1 rounded-xl border border-slate-800">
          <button
            onClick={() => setActiveTab('api_sec')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
              activeTab === 'api_sec' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'
            }`}
          >
            API Security (BOLA / BFLA)
          </button>
          <button
            onClick={() => setActiveTab('evaluation')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
              activeTab === 'evaluation' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'
            }`}
          >
            Benchmark & Evaluation (F1)
          </button>
          <button
            onClick={() => setActiveTab('collaboration')}
            className={`px-4 py-2 text-xs font-semibold rounded-lg transition-all ${
              activeTab === 'collaboration' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-400 hover:text-white'
            }`}
          >
            2-Node Transfer & CIA+AA
          </button>
        </div>
      </div>

      {/* Global Project & Target Bar */}
      {activeTab !== 'collaboration' && (
        <div className="bg-[#0F1523] border border-slate-800 rounded-xl p-4 flex flex-wrap items-center gap-4">
          <label className="flex items-center gap-2 text-sm text-slate-300">
            Project:
            <select
              className={fieldClass}
              value={selectedProjectId}
              onChange={(e) => {
                setSelectedProjectId(e.target.value);
                setSelectedTargetId('');
              }}
            >
              <option value="">Select Project</option>
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                </option>
              ))}
            </select>
          </label>

          {activeTab === 'api_sec' && (
            <label className="flex items-center gap-2 text-sm text-slate-300">
              Approved Target:
              <select
                className={fieldClass}
                value={selectedTargetId}
                disabled={!selectedProjectId}
                onChange={(e) => setSelectedTargetId(e.target.value)}
              >
                <option value="">Select Target</option>
                {targets.map((t) => (
                  <option key={t.id} value={t.id} disabled={t.authorization_status !== 'APPROVED' || !t.is_active}>
                    {t.name} ({t.url}) [{t.authorization_status}]
                  </option>
                ))}
              </select>
            </label>
          )}
        </div>
      )}

      {/* ================================================================ */}
      {/* TAB 1: API Security (OpenAPI & BOLA/BFLA) */}
      {/* ================================================================ */}
      {activeTab === 'api_sec' && (
        <div className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Import OpenAPI Spec */}
            <div className="bg-[#0F1523] border border-slate-800 rounded-xl p-6 space-y-4">
              <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                <FileCode className="text-indigo-400" size={20} />
                OpenAPI / Swagger Spec Ingestion
              </h3>
              <p className="text-xs text-slate-400">
                Upload OpenAPI 3.0 / Swagger JSON or YAML. Extracts routes, authentication requirements, path parameters, and object identifier patterns.
              </p>

              <div>
                <input
                  type="file"
                  accept=".json,.yaml,.yml"
                  className={fieldClass}
                  onChange={(e) => setOpenApiFile(e.target.files?.[0] || null)}
                />
              </div>

              <button
                className={buttonPrimary}
                disabled={!selectedProjectId || !selectedTargetId || !openApiFile || importMutation.isPending}
                onClick={() => openApiFile && importMutation.mutate(openApiFile)}
              >
                {importMutation.isPending ? 'Parsing Specification…' : 'Import & Analyze Spec'}
              </button>

              {parsedSpec && (
                <div className="mt-4 p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-slate-200">{parsedSpec.title}</span>
                    <span className="text-indigo-400 font-mono">v{parsedSpec.version}</span>
                  </div>
                  <p className="text-xs text-slate-400">
                    Discovered {parsedSpec.parsed_endpoints_count} parsed endpoints ready for authorization checks.
                  </p>
                </div>
              )}
            </div>

            {/* Run Persona Auth Test */}
            <div className="bg-[#0F1523] border border-slate-800 rounded-xl p-6 space-y-4">
              <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                <Key className="text-indigo-400" size={20} />
                Synthetic Persona Security Testing
              </h3>
              <p className="text-xs text-slate-400">
                Exercises API endpoints against controlled synthetic personas (<span className="text-indigo-300 font-mono">USER_A</span>, <span className="text-indigo-300 font-mono">USER_B</span>, <span className="text-indigo-300 font-mono">ADMIN</span>, <span className="text-indigo-300 font-mono">UNAUTHENTICATED</span>) to detect BOLA, BFLA, and broken auth.
              </p>

              <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-xs text-slate-400 space-y-1">
                <p>• Scope and SSRF verified prior to dispatch.</p>
                <p>• All authorization headers, cookies, and tokens are redacted before persistence.</p>
                <p>• Strict non-destructive read & validation operations only.</p>
              </div>

              <button
                className={buttonPrimary}
                disabled={!selectedProjectId || !selectedTargetId || runAuthTestMutation.isPending}
                onClick={() => runAuthTestMutation.mutate()}
              >
                {runAuthTestMutation.isPending ? 'Executing Persona Matrix…' : 'Run API Authorization Tests'}
              </button>
            </div>
          </div>

          {/* Test Results */}
          {authTestResult && (
            <div className="bg-[#0F1523] border border-slate-800 rounded-xl p-6 space-y-4">
              <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 pb-3">
                <h4 className="font-semibold text-white flex items-center gap-2">
                  <Activity className="text-indigo-400" size={18} />
                  Authorization Assessment Results ({authTestResult.target_url})
                </h4>
                <div className="flex gap-4 text-xs font-mono">
                  <span className="text-slate-400">Tests Run: <strong className="text-white">{authTestResult.tests_run}</strong></span>
                  <span className="text-slate-400">Vulnerabilities: <strong className={authTestResult.vulnerabilities_found > 0 ? 'text-red-400' : 'text-emerald-400'}>{authTestResult.vulnerabilities_found}</strong></span>
                </div>
              </div>

              {authTestResult.findings.length === 0 ? (
                <p className="text-sm text-emerald-400 py-3 flex items-center gap-2">
                  <CheckCircle size={18} /> No BOLA, BFLA, or unauthenticated privilege escalations detected across tested personas.
                </p>
              ) : (
                <div className="space-y-3">
                  {authTestResult.findings.map((f) => (
                    <div key={f.id} className="p-4 bg-slate-950 rounded-lg border border-red-900/50 space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="text-sm font-semibold text-red-400">[{f.vulnerability_type}] {f.method} {f.path}</span>
                        <span className="text-xs px-2 py-0.5 rounded bg-red-950 text-red-300 border border-red-800">{f.severity}</span>
                      </div>
                      <p className="text-xs text-slate-300">{f.details}</p>
                      <div className="text-[11px] text-slate-500 font-mono">
                        Persona: {f.persona_tested} | Observed HTTP Status: {f.status_code_observed}
                      </div>
                      <pre className="text-[11px] bg-slate-900 p-2 rounded text-slate-400 overflow-x-auto whitespace-pre-wrap">
                        {JSON.stringify(f.evidence, null, 2)}
                      </pre>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* ================================================================ */}
      {/* TAB 2: Benchmark Evaluation & Correlation */}
      {/* ================================================================ */}
      {activeTab === 'evaluation' && (
        <div className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Ground Truth Benchmark */}
            <div className="bg-[#0F1523] border border-slate-800 rounded-xl p-6 space-y-4">
              <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                <Activity className="text-indigo-400" size={20} />
                Ground Truth Benchmark & Metrics
              </h3>
              <p className="text-xs text-slate-400">
                Evaluates scanner accuracy against 10 ground truth cases across SQLi, Command Injection, Code Execution, Secrets, and Weak Cryptography.
              </p>

              <div className="flex gap-3">
                <button
                  className={buttonPrimary}
                  disabled={evalMutation.isPending}
                  onClick={() => evalMutation.mutate(true)}
                >
                  {evalMutation.isPending ? 'Evaluating Ground Truth…' : 'Run Benchmark Evaluation'}
                </button>
              </div>

              {benchmarkResult && (
                <div className="mt-4 space-y-4">
                  {/* Confusion Matrix & Metrics */}
                  <div className="grid grid-cols-4 gap-2 text-center text-xs">
                    <div className="p-2 bg-slate-950 rounded border border-slate-800">
                      <div className="text-slate-500 text-[10px]">Precision</div>
                      <div className="text-base font-bold text-indigo-400">{(benchmarkResult.metrics.precision * 100).toFixed(1)}%</div>
                    </div>
                    <div className="p-2 bg-slate-950 rounded border border-slate-800">
                      <div className="text-slate-500 text-[10px]">Recall</div>
                      <div className="text-base font-bold text-indigo-400">{(benchmarkResult.metrics.recall * 100).toFixed(1)}%</div>
                    </div>
                    <div className="p-2 bg-slate-950 rounded border border-slate-800">
                      <div className="text-slate-500 text-[10px]">F1 Score</div>
                      <div className="text-base font-bold text-emerald-400">{(benchmarkResult.metrics.f1 * 100).toFixed(1)}%</div>
                    </div>
                    <div className="p-2 bg-slate-950 rounded border border-slate-800">
                      <div className="text-slate-500 text-[10px]">Accuracy</div>
                      <div className="text-base font-bold text-indigo-400">{(benchmarkResult.metrics.accuracy * 100).toFixed(1)}%</div>
                    </div>
                  </div>

                  <div className="p-3 bg-slate-950 rounded border border-slate-800 text-xs flex justify-around">
                    <span>TP: <strong className="text-emerald-400">{benchmarkResult.confusion_matrix.true_positives}</strong></span>
                    <span>FP: <strong className="text-amber-400">{benchmarkResult.confusion_matrix.false_positives}</strong></span>
                    <span>TN: <strong className="text-blue-400">{benchmarkResult.confusion_matrix.true_negatives}</strong></span>
                    <span>FN: <strong className="text-red-400">{benchmarkResult.confusion_matrix.false_negatives}</strong></span>
                  </div>
                </div>
              )}
            </div>

            {/* Cross-Tool Correlation */}
            <div className="bg-[#0F1523] border border-slate-800 rounded-xl p-6 space-y-4">
              <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                <RefreshCw className="text-indigo-400" size={20} />
                Cross-Tool Findings Correlation
              </h3>
              <p className="text-xs text-slate-400">
                Calculates pairwise Jaccard correlation between tools (Semgrep, Gitleaks, ZAP, AI) for the active project. Highlights multi-tool verified vs tool-unique findings without masking divergence.
              </p>

              <button
                className={buttonPrimary}
                disabled={!selectedProjectId || correlationMutation.isPending}
                onClick={() => selectedProjectId && correlationMutation.mutate(selectedProjectId)}
              >
                {correlationMutation.isPending ? 'Correlating Findings…' : 'Calculate Tool Correlation'}
              </button>

              {correlationResult && (
                <div className="mt-4 space-y-3">
                  <div className="text-xs text-slate-400">
                    Total Findings Analyzed: <strong className="text-white">{correlationResult.total_findings}</strong> | Tools: {correlationResult.tools_analyzed.join(', ')}
                  </div>

                  <div className="space-y-1.5">
                    {correlationResult.pairwise_correlations.map((pair, idx) => (
                      <div key={idx} className="p-2 bg-slate-950 rounded border border-slate-800 text-xs flex justify-between">
                        <span>{pair.tool_a} ↔ {pair.tool_b}</span>
                        <span className="font-mono text-indigo-400">
                          {pair.shared_findings_count} shared (Jaccard: {(pair.correlation_coefficient * 100).toFixed(0)}%)
                        </span>
                      </div>
                    ))}
                  </div>

                  <div className="text-xs text-slate-400">
                    Multi-Tool Confirmed: <strong className="text-emerald-400">{correlationResult.multi_tool_confirmed_findings.length}</strong> findings.
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Benchmark Detailed Results Table */}
          {benchmarkResult && (
            <div className="bg-[#0F1523] border border-slate-800 rounded-xl p-6 space-y-4">
              <h4 className="font-semibold text-white text-sm">Ground Truth Cases Breakdown</h4>
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs text-slate-300">
                  <thead className="bg-slate-950 text-slate-400">
                    <tr>
                      <th className="p-2.5">Case ID</th>
                      <th className="p-2.5">Category</th>
                      <th className="p-2.5">Expected Ground Truth</th>
                      <th className="p-2.5">Semgrep Detected</th>
                      <th className="p-2.5">Classification</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800">
                    {benchmarkResult.detailed_results.map((r) => (
                      <tr key={r.case_id} className="hover:bg-slate-800/40">
                        <td className="p-2.5 font-mono">{r.case_id}</td>
                        <td className="p-2.5">{r.category}</td>
                        <td className="p-2.5 font-mono">{r.expected}</td>
                        <td className="p-2.5">{r.detected_by_semgrep ? 'YES' : 'NO'}</td>
                        <td className="p-2.5">
                          <span
                            className={`px-2 py-0.5 rounded font-mono text-[10px] ${
                              r.classification.startsWith('TRUE_') ? 'bg-emerald-950 text-emerald-300' : 'bg-red-950 text-red-300'
                            }`}
                          >
                            {r.classification}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ================================================================ */}
      {/* TAB 3: 2-Node Encrypted Transfer & CIA+AA Evaluation */}
      {/* ================================================================ */}
      {activeTab === 'collaboration' && (
        <div className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            {/* Sender Node A */}
            <div className="bg-[#0F1523] border border-slate-800 rounded-xl p-6 space-y-4">
              <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                <Send className="text-indigo-400" size={20} />
                Node A: Authenticated Encrypted Dispatch
              </h3>
              <p className="text-xs text-slate-400">
                Transfers text, images, audio, or video between two nodes using authenticated AES-256-GCM encryption with SHA-256 integrity verification.
              </p>

              <div className="space-y-3">
                <label className="block text-xs text-slate-300">
                  Payload Type:
                  <select
                    className={fieldClass}
                    value={payloadType}
                    onChange={(e) => setPayloadType(e.target.value)}
                  >
                    <option value="TEXT">TEXT (Analysis, Findings, Commands)</option>
                    <option value="IMAGE">IMAGE (Screenshots, Evidence)</option>
                    <option value="AUDIO">AUDIO (Voice Notes, Alerts)</option>
                    <option value="VIDEO">VIDEO (Screen Recording, PoC)</option>
                  </select>
                </label>

                <label className="block text-xs text-slate-300">
                  Content / Payload:
                  <textarea
                    rows={3}
                    className={fieldClass}
                    value={textContent}
                    onChange={(e) => setTextContent(e.target.value)}
                  />
                </label>

                <label className="block text-xs text-slate-300">
                  Pre-shared Secret:
                  <input
                    type="password"
                    className={fieldClass}
                    value={sharedSecret}
                    onChange={(e) => setSharedSecret(e.target.value)}
                  />
                </label>

                <button
                  className={buttonPrimary}
                  disabled={sendMutation.isPending || !textContent}
                  onClick={() => sendMutation.mutate()}
                >
                  {sendMutation.isPending ? 'Encrypting & Dispatching…' : 'Encrypt & Send to Node B (AES-256-GCM)'}
                </button>
              </div>

              {transferResponse && (
                <div className="p-3 bg-slate-950 rounded-lg border border-slate-800 text-xs space-y-1">
                  <div className="flex justify-between items-center text-emerald-400 font-semibold">
                    <span>Status: {transferResponse.delivery_status}</span>
                    <span className="text-[10px] text-slate-500">{transferResponse.transfer_id}</span>
                  </div>
                  <p className="text-slate-400 font-mono break-all text-[11px]">
                    SHA-256: {transferResponse.integrity.sha256}
                  </p>
                  <p className="text-slate-500 font-mono break-all text-[10px]">
                    Ciphertext: {transferResponse.package.ciphertext.slice(0, 40)}…
                  </p>
                </div>
              )}
            </div>

            {/* Receiver Node B */}
            <div className="bg-[#0F1523] border border-slate-800 rounded-xl p-6 space-y-4">
              <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                <ArrowRightLeft className="text-indigo-400" size={20} />
                Node B: Authenticated Ingestion & Decryption
              </h3>
              <p className="text-xs text-slate-400">
                Receives encrypted payload, verifies GCM authentication tag and SHA-256 integrity hash, and decrypts the payload. Tampered payloads fail verification.
              </p>

              <button
                className={buttonSecondary}
                disabled={!transferResponse?.package || receiveMutation.isPending}
                onClick={() => receiveMutation.mutate()}
              >
                {receiveMutation.isPending ? 'Authenticating & Decrypting…' : 'Decrypt & Verify Node B Payload'}
              </button>

              {receiveResponse && (
                <div className="p-4 bg-slate-950 rounded-lg border border-slate-800 space-y-2">
                  <div className="flex justify-between items-center text-xs">
                    <span className="font-semibold text-emerald-400 flex items-center gap-1.5">
                      <CheckCircle size={14} /> Integrity Verified (SHA-256 & GCM Tag)
                    </span>
                    <span className="text-slate-500 text-[10px]">Sender: {receiveResponse.sender_node_id}</span>
                  </div>
                  <div className="p-3 bg-slate-900 rounded font-mono text-xs text-slate-200 whitespace-pre-wrap">
                    {receiveResponse.content}
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* CIA+AA Goals & Performance Profile */}
          {secEval && (
            <div className="bg-[#0F1523] border border-slate-800 rounded-xl p-6 space-y-6">
              <div className="flex justify-between items-center border-b border-slate-800 pb-3">
                <h4 className="font-semibold text-white text-base flex items-center gap-2">
                  <Cpu className="text-indigo-400" size={18} />
                  Security Goals (CIA+AA) Compliance & Performance Profiling
                </h4>
                <button
                  className="text-xs text-indigo-400 hover:underline flex items-center gap-1"
                  onClick={() => refetchSecEval()}
                >
                  <RefreshCw size={12} /> Refresh Metrics
                </button>
              </div>

              {/* CIA+AA 5 Pillars */}
              <div className="grid md:grid-cols-5 gap-3">
                {Object.entries(secEval.cia_aa_status).map(([pillar, detail]) => (
                  <div key={pillar} className="p-3 bg-slate-950 rounded-lg border border-slate-800 space-y-1">
                    <div className="text-[10px] text-slate-500 uppercase tracking-wider">{pillar}</div>
                    <div className="text-xs font-bold text-emerald-400">{detail.status}</div>
                    <div className="text-[10px] text-slate-400">{detail.mechanism}</div>
                  </div>
                ))}
              </div>

              {/* Performance Profile */}
              <div className="grid md:grid-cols-4 gap-4 p-4 bg-slate-950 rounded-lg border border-slate-800 text-center">
                <div>
                  <div className="text-xs text-slate-500">System CPU Load</div>
                  <div className="text-lg font-bold text-slate-200">{secEval.performance_profile.cpu_percent}%</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Resident Memory</div>
                  <div className="text-lg font-bold text-slate-200">{secEval.performance_profile.memory_mb.toFixed(1)} MB</div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Crypto Throughput</div>
                  <div className="text-lg font-bold text-indigo-400">
                    {secEval.performance_profile.crypto_benchmark_throughput_mb_s.toFixed(1)} MB/s
                  </div>
                </div>
                <div>
                  <div className="text-xs text-slate-500">Node Transfer Latency</div>
                  <div className="text-lg font-bold text-emerald-400">
                    {secEval.performance_profile.transfer_roundtrip_ms.toFixed(2)} ms
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
