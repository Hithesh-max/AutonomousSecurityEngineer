"""Tests for isolated build, functional, and security verification runner."""
from pathlib import Path
from types import SimpleNamespace
from uuid import uuid4
import os
import pytest

from app.verification.runner import (
    create_isolated_environment, detect_project_runner,
    verify_project_changes, VerificationStatus
)


def test_isolated_environment_strips_secrets(monkeypatch):
    monkeypatch.setenv("JWT_SECRET", "super_secret_production_key_123456789")
    monkeypatch.setenv("DATABASE_URL", "postgresql://user:pass@localhost/db")
    monkeypatch.setenv("OPENAI_API_KEY", "sk-proj-test-123456")

    env = create_isolated_environment()
    assert "JWT_SECRET" not in env
    assert "DATABASE_URL" not in env
    assert "OPENAI_API_KEY" not in env
    assert env["HTTP_PROXY"] == "http://127.0.0.1:0"
    assert env["CI"] == "true"


def test_detect_project_runner(tmp_path):
    # Empty dir
    res = detect_project_runner(tmp_path)
    assert res["runner_type"] == "NONE"

    # Python project
    (tmp_path / "requirements.txt").write_text("pytest\n")
    res = detect_project_runner(tmp_path)
    assert res["runner_type"] == "PYTHON"

    # Node.js project
    node_dir = tmp_path / "node_proj"
    node_dir.mkdir()
    (node_dir / "package.json").write_text('{"name": "test"}')
    res_node = detect_project_runner(node_dir)
    assert res_node["runner_type"] == "NODEJS"


def test_verify_syntax_only_is_inconclusive(tmp_path):
    # Setup test file
    code_file = tmp_path / "app.py"
    code_file.write_text("x = 1\ny = 2\n")

    finding_id = uuid4()
    finding = SimpleNamespace(
        id=finding_id,
        source_location={"file": "app.py"}
    )
    proposal = SimpleNamespace(
        id=uuid4(),
        finding_id=finding_id,
        source_path="app.py",
        edits=[{"start_line": 2, "end_line": 2, "replacement_text": "y = 3"}]
    )
    source = SimpleNamespace(lines=["x = 1", "y = 2"], path="app.py")

    result = verify_project_changes(
        tmp_path,
        [proposal],
        {"app.py": source},
        [finding]
    )

    # In absence of functional tests, syntax check pass alone MUST be INCONCLUSIVE
    assert len(result["finding_evaluations"]) == 1
    eval_item = result["finding_evaluations"][0]
    assert eval_item["status"] == VerificationStatus.INCONCLUSIVE
    assert "not proof of a fix" in eval_item["evidence"]


def test_verify_syntax_failure_is_failed(tmp_path):
    code_file = tmp_path / "app.py"
    code_file.write_text("x = 1\ny = 2\n")

    finding_id = uuid4()
    finding = SimpleNamespace(
        id=finding_id,
        source_location={"file": "app.py"}
    )
    proposal = SimpleNamespace(
        id=uuid4(),
        finding_id=finding_id,
        source_path="app.py",
        edits=[{"start_line": 2, "end_line": 2, "replacement_text": "y = (broken syntax {"}]
    )
    source = SimpleNamespace(lines=["x = 1", "y = 2"], path="app.py")

    result = verify_project_changes(
        tmp_path,
        [proposal],
        {"app.py": source},
        [finding]
    )

    assert result["overall_status"] == VerificationStatus.FAILED
    assert result["finding_evaluations"][0]["status"] == VerificationStatus.FAILED
