"""API routes for multi-node encrypted transfer and security goals evaluation."""
import base64
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, ConfigDict, Field

from app.api.auth import get_current_user
from app.config.settings import settings
from app.models.user import User
from app.collaboration.node_transfer import (
    derive_node_key, encrypt_payload, decrypt_and_verify_payload,
    get_transfer_audit_log, MediaType
)
from app.collaboration.security_evaluation import run_full_security_goals_evaluation

router = APIRouter()


class NodeTransferRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    media_type: str = Field(pattern="^(TEXT|IMAGE|AUDIO|VIDEO)$")
    sender_node: str = Field(min_length=2, max_length=50)
    receiver_node: str = Field(min_length=2, max_length=50)
    payload_b64: str = Field(min_length=1)
    shared_key_seed: str | None = None


class NodeReceiveRequest(BaseModel):
    model_config = ConfigDict(extra="forbid")
    packet: dict
    shared_key_seed: str | None = None


@router.post("/collaboration/node-transfer", status_code=201)
def transfer_media_packet(
    body: NodeTransferRequest,
    current_user: User = Depends(get_current_user)
):
    """Encrypt text, image, audio, or video payload using AES-256-GCM for secure node-to-node transfer."""
    try:
        raw_bytes = base64.b64decode(body.payload_b64)
    except Exception:
        raise HTTPException(400, detail="Payload must be valid base64 encoded data.")

    key_seed = body.shared_key_seed or settings.JWT_SECRET
    encryption_key = derive_node_key(key_seed)

    packet = encrypt_payload(
        raw_bytes=raw_bytes,
        media_type=body.media_type,
        sender_node=body.sender_node,
        receiver_node=body.receiver_node,
        encryption_key=encryption_key
    )
    return packet


@router.post("/collaboration/node-receive")
def receive_media_packet(
    body: NodeReceiveRequest,
    current_user: User = Depends(get_current_user)
):
    """Decrypt and verify received media packet with cryptographic authentication and SHA-256 integrity check."""
    key_seed = body.shared_key_seed or settings.JWT_SECRET
    encryption_key = derive_node_key(key_seed)

    try:
        result = decrypt_and_verify_payload(body.packet, encryption_key)
        return {
            "transfer_id": result["transfer_id"],
            "media_type": result["media_type"],
            "verified_sha256": result["verified_sha256"],
            "integrity_verified": True,
            "decryption_latency_ms": result["decryption_latency_ms"],
            "payload_b64": base64.b64encode(result["raw_bytes"]).decode("ascii")
        }
    except (PermissionError, ValueError) as e:
        raise HTTPException(403, detail=str(e))


@router.get("/collaboration/audit-log")
def get_audit_log(current_user: User = Depends(get_current_user)):
    """Retrieve access-controlled transfer event log."""
    return get_transfer_audit_log()


@router.get("/collaboration/security-evaluation")
def get_security_evaluation(current_user: User = Depends(get_current_user)):
    """Execute and return CIA+AA security goals evaluation and performance profiling."""
    return run_full_security_goals_evaluation()
