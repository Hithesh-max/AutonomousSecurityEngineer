"""Isolated execution runner for build, functional, and security verification.

Does NOT execute uploaded projects inside the trusted API/worker process environment.
Enforces resource limits, execution timeouts, stripped environment variables, and network boundaries.
"""
from dataclasses import dataclass, asdict
from datetime import datetime, timezone
from hashlib import sha256
import os
from pathlib import Path
import shutil
import subprocess
import tempfile
from typing import Any

from app.remediation.languages import syntax_check, supports
from app.remediation.export import apply_edits, _patched_bytes


class VerificationStatus:
    VERIFIED_FIXED = "VERIFIED_FIXED"
    STILL_VULNERABLE = "STILL_VULNERABLE"
    REGRESSION = "REGRESSION"
    FAILED = "FAILED"
    UNSUPPORTED = "UNSUPPORTED"
    INCONCLUSIVE = "INCONCLUSIVE"


# Environment variables to strip from execution sandbox
SENSITIVE_ENV_KEYS = {
    "JWT_SECRET", "DATABASE_URL", "REDIS_URL", "OPENAI_API_KEY", "GEMINI_API_KEY",
    "AI_API_KEY", "ZAP_API_KEY", "POSTGRES_PASSWORD", "SECRET_KEY"
}


def create_isolated_environment() -> dict[str, str]:
    """Create a minimal, sanitized environment with secrets removed."""
    clean_env = {}
    allowed_keys = {
        "PATH", "PATHEXT", "SYSTEMROOT", "WINDIR", "TMP", "TEMP", "USERPROFILE",
        "HOMEDRIVE", "HOMEPATH", "LANG", "LC_ALL", "NODE_ENV", "PYTHONPATH"
    }
    for k, v in os.environ.items():
        if k.upper() in allowed_keys and k.upper() not in SENSITIVE_ENV_KEYS:
            clean_env[k] = v

    # Restrict outbound network during builds/tests to prevent SSRF and data exfiltration
    clean_env["HTTP_PROXY"] = "http://127.0.0.1:0"
    clean_env["HTTPS_PROXY"] = "http://127.0.0.1:0"
    clean_env["NO_PROXY"] = "localhost,127.0.0.1"
    clean_env["CI"] = "true"
    return clean_env


def run_bounded_process(args: list[str], cwd: Path, timeout_seconds: int = 45, max_output_chars: int = 50000) -> dict:
    """Execute process in isolated directory with bounds on time and output length."""
    env = create_isolated_environment()
    try:
        proc = subprocess.run(
            args,
            cwd=str(cwd),
            env=env,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=timeout_seconds,
            text=True,
            errors="replace"
        )
        stdout = proc.stdout[:max_output_chars]
        stderr = proc.stderr[:max_output_chars]
        return {
            "success": proc.returncode == 0,
            "returncode": proc.returncode,
            "stdout": stdout,
            "stderr": stderr,
            "timed_out": False
        }
    except subprocess.TimeoutExpired:
        return {
            "success": False,
            "returncode": -1,
            "stdout": "",
            "stderr": f"Process exceeded execution timeout of {timeout_seconds}s.",
            "timed_out": True
        }
    except FileNotFoundError:
        return {
            "success": False,
            "returncode": -1,
            "stdout": "",
            "stderr": f"Command not found: {args[0]}",
            "timed_out": False
        }


def detect_project_runner(repo_dir: Path) -> dict:
    """Detect available build systems and test frameworks."""
    has_package_json = (repo_dir / "package.json").is_file()
    has_pyproject = (repo_dir / "pyproject.toml").is_file() or (repo_dir / "requirements.txt").is_file()
    has_pom = (repo_dir / "pom.xml").is_file()
    has_cargo = (repo_dir / "Cargo.toml").is_file()
    has_tests = any((repo_dir / p).exists() for p in ["tests", "test", "spec", "__tests__"])

    runner = "NONE"
    build_cmd = None
    test_cmd = None

    if has_package_json:
        runner = "NODEJS"
        build_cmd = ["npm", "run", "build", "--if-present"]
        test_cmd = ["npm", "test", "--if-present"]
    elif has_pyproject:
        runner = "PYTHON"
        build_cmd = ["python", "-m", "compileall", "-q", "."]
        test_cmd = ["pytest", "-q"] if has_tests else None
    elif has_pom:
        runner = "JAVA_MAVEN"
        build_cmd = ["mvn", "compile", "-q"]
        test_cmd = ["mvn", "test", "-q"] if has_tests else None
    elif has_cargo:
        runner = "RUST_CARGO"
        build_cmd = ["cargo", "check", "-q"]
        test_cmd = ["cargo", "test", "-q"] if has_tests else None

    return {
        "runner_type": runner,
        "has_tests": has_tests,
        "build_cmd": build_cmd,
        "test_cmd": test_cmd
    }


def verify_project_changes(
    original_repo_root: Path,
    proposals: list[Any],
    sources: dict[str, Any],
    findings: list[Any]
) -> dict:
    """
    Execute end-to-end isolated verification of approved patches.
    Copies repository to an isolated scratchpad, applies changes, and executes:
    1. Syntax checks
    2. Build checks
    3. Functional test suite
    4. Before/after security evidence classification
    """
    with tempfile.TemporaryDirectory(prefix="ase-verify-") as tmpdir:
        isolated_root = Path(tmpdir) / "project"
        # Copy original repository files to isolated tempdir
        shutil.copytree(original_repo_root, isolated_root, symlinks=False)

        # 1. Apply approved patches to isolated copy
        applied_files = {}
        for p in proposals:
            path = getattr(p, "source_path", None)
            source = sources.get(path)
            if not source or not path:
                continue

            target_file = isolated_root / path
            if not target_file.is_file():
                continue

            try:
                content = apply_edits(source.lines, p.edits)
                target_file.write_bytes(content)
                applied_files[path] = {
                    "patch_id": str(p.id),
                    "patched_sha256": sha256(content).hexdigest(),
                    "syntax_check": syntax_check(path, content.decode("utf-8", errors="replace"))
                }
            except Exception as e:
                applied_files[path] = {
                    "patch_id": str(p.id),
                    "error": str(e),
                    "syntax_check": {"status": "FAIL", "detail": f"Failed to apply patch: {str(e)}"}
                }

        # Check if any syntax check failed
        syntax_failures = [
            f for f, info in applied_files.items()
            if info.get("syntax_check", {}).get("status") == "FAIL"
        ]
        if syntax_failures:
            return {
                "overall_status": VerificationStatus.FAILED,
                "summary": f"Syntax validation failed in modified files: {syntax_failures}",
                "applied_files": applied_files,
                "build_result": None,
                "test_result": None,
                "finding_evaluations": [
                    {
                        "finding_id": str(f.id),
                        "status": VerificationStatus.FAILED,
                        "evidence": "Syntax check failed on proposed patch."
                    } for f in findings
                ]
            }

        # 2. Build verification in isolated copy
        runner_info = detect_project_runner(isolated_root)
        build_result = None
        if runner_info["build_cmd"]:
            build_result = run_bounded_process(runner_info["build_cmd"], isolated_root, timeout_seconds=60)
            if not build_result["success"] and not build_result.get("command_not_found"):
                return {
                    "overall_status": VerificationStatus.REGRESSION,
                    "summary": "Build validation failed on corrected project copy.",
                    "applied_files": applied_files,
                    "build_result": build_result,
                    "test_result": None,
                    "finding_evaluations": [
                        {
                            "finding_id": str(f.id),
                            "status": VerificationStatus.REGRESSION,
                            "evidence": f"Patches caused build regression: {build_result['stderr'][:300]}"
                        } for f in findings
                    ]
                }

        # 3. Functional test suite execution
        test_result = None
        if runner_info["test_cmd"]:
            test_result = run_bounded_process(runner_info["test_cmd"], isolated_root, timeout_seconds=90)

        # 4. Finding-by-finding evaluation
        evaluations = []
        for f in findings:
            fid = str(f.id)
            matching_proposal = next((p for p in proposals if getattr(p, "finding_id", None) == f.id), None)

            if not matching_proposal:
                evaluations.append({
                    "finding_id": fid,
                    "status": "UNRESOLVED",
                    "evidence": "No approved patch for this finding."
                })
                continue

            src_path = (f.source_location or {}).get("file")
            file_info = applied_files.get(src_path, {})
            syntax_res = file_info.get("syntax_check", {})

            if syntax_res.get("status") != "PASS":
                evaluations.append({
                    "finding_id": fid,
                    "status": VerificationStatus.FAILED,
                    "evidence": "Syntax check did not pass for patched file."
                })
            elif test_result and not test_result["success"]:
                evaluations.append({
                    "finding_id": fid,
                    "status": VerificationStatus.REGRESSION,
                    "evidence": f"Project test suite failed after applying patch: {test_result['stderr'][:250]}"
                })
            elif test_result and test_result["success"]:
                evaluations.append({
                    "finding_id": fid,
                    "status": VerificationStatus.VERIFIED_FIXED,
                    "evidence": "Patch passed syntax checks and project test suite passed successfully."
                })
            else:
                # Syntax passed, but no automated functional tests existed
                evaluations.append({
                    "finding_id": fid,
                    "status": VerificationStatus.INCONCLUSIVE,
                    "evidence": (
                        "Syntax check passed without execution. "
                        "A missing scanner alert or syntax pass alone is not proof of a fix; dynamic or manual confirmation is required."
                    )
                })

        overall_status = VerificationStatus.VERIFIED_FIXED if all(
            e["status"] in (VerificationStatus.VERIFIED_FIXED, "UNRESOLVED") for e in evaluations
        ) and any(e["status"] == VerificationStatus.VERIFIED_FIXED for e in evaluations) else VerificationStatus.INCONCLUSIVE

        return {
            "overall_status": overall_status,
            "runner_type": runner_info["runner_type"],
            "applied_files": applied_files,
            "build_result": build_result,
            "test_result": test_result,
            "finding_evaluations": evaluations,
            "verification_timestamp": datetime.now(timezone.utc).isoformat(),
            "coverage_limitations": [
                "Static syntax checking is not type checking, compilation, or runtime testing.",
                "Missing scanner alert alone is never classified as VERIFIED_FIXED.",
                "Executing untrusted projects without container virtualization is bounded to isolated temp sub-processes."
            ]
        }
