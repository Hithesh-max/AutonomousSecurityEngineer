"""Controlled BOLA and BFLA authorization testing with credential redaction."""
from datetime import datetime, timezone
import re
from typing import Any
import urllib.request
import urllib.error

from app.network.scope import resolve_and_verify_destination, check_ssrf


def redact_auth_header(header_value: str) -> str:
    """Redact tokens or passwords in authorization headers."""
    if not header_value:
        return ""
    if header_value.lower().startswith("bearer "):
        return "Bearer [REDACTED_TOKEN]"
    if header_value.lower().startswith("basic "):
        return "Basic [REDACTED_CREDENTIALS]"
    return "[REDACTED]"


def execute_auth_probe(
    url: str,
    method: str,
    headers: dict[str, str],
    timeout_seconds: int = 5
) -> dict[str, Any]:
    """Execute single HTTP probe and record status code and response header evidence."""
    req = urllib.request.Request(url, method=method)
    for k, v in headers.items():
        req.add_header(k, v)

    # Redact sensitive headers for storage
    stored_headers = {}
    for k, v in headers.items():
        if k.lower() in ("authorization", "cookie", "x-api-key"):
            stored_headers[k] = redact_auth_header(v)
        else:
            stored_headers[k] = v

    try:
        with urllib.request.urlopen(req, timeout=timeout_seconds) as resp:
            status = resp.status
            body_sample = resp.read(512).decode("utf-8", errors="replace")
            return {
                "status_code": status,
                "error": None,
                "headers": stored_headers,
                "body_sample": body_sample[:200]
            }
    except urllib.error.HTTPError as e:
        return {
            "status_code": e.code,
            "error": str(e),
            "headers": stored_headers,
            "body_sample": ""
        }
    except Exception as e:
        return {
            "status_code": None,
            "error": str(e)[:200],
            "headers": stored_headers,
            "body_sample": ""
        }


def run_authorization_tests(
    base_url: str,
    endpoints: list[dict[str, Any]],
    synthetic_users: dict[str, dict[str, str]],
    explicit_scope: str | None = None
) -> dict[str, Any]:
    """
    Run controlled BOLA and BFLA checks across candidate endpoints.
    synthetic_users format:
    {
        "USER_A": {"token": "..."},
        "USER_B": {"token": "..."},
        "ADMIN": {"token": "..."},
        "UNAUTHENTICATED": {"token": None}
    }
    """
    # Verify target base URL passes SSRF and scope check before testing
    resolve_and_verify_destination(base_url, explicit_scope)

    results = []
    user_a_token = synthetic_users.get("USER_A", {}).get("token")
    user_b_token = synthetic_users.get("USER_B", {}).get("token")
    admin_token = synthetic_users.get("ADMIN", {}).get("token")

    for ep in endpoints:
        path = ep["path"]
        method = ep["method"]
        is_bola_cand = ep.get("bola_candidate", False)
        is_bfla_cand = ep.get("bfla_candidate", False)

        if not is_bola_cand and not is_bfla_cand:
            continue

        # 1. BOLA Check: Accessing User A's resource with User B's token
        if is_bola_cand:
            # Substitute synthetic User A resource ID
            test_path = re.sub(r"\{[a-zA-Z0-9_\-]*id[a-zA-Z0-9_\-]*\}", "resource-user-a", path, flags=re.IGNORECASE)
            target_url = f"{base_url.rstrip('/')}/{test_path.lstrip('/')}"

            headers = {"User-Agent": "ASE-AuthAudit/1.0"}
            if user_b_token:
                headers["Authorization"] = f"Bearer {user_b_token}"

            probe = execute_auth_probe(target_url, method, headers)

            # Evaluate BOLA: User B should be denied access to User A's object
            obs_code = probe["status_code"]
            if obs_code in (200, 201, 204):
                status = "VULNERABLE"
                finding_title = f"BOLA: Object-level access granted to unauthorized user on {method} {path}"
                evidence = f"User B requested User A resource and received HTTP {obs_code}. Expected 403 or 404."
            elif obs_code in (401, 403, 404):
                status = "SECURE"
                finding_title = None
                evidence = f"Access denied with HTTP {obs_code} as expected."
            elif obs_code is None:
                status = "INCONCLUSIVE"
                finding_title = None
                evidence = f"Probe failed or timed out: {probe['error']}"
            else:
                status = "INCONCLUSIVE"
                finding_title = None
                evidence = f"Received unhandled status code HTTP {obs_code}."

            results.append({
                "test_type": "BOLA",
                "endpoint": path,
                "method": method,
                "status": status,
                "observed_status_code": obs_code,
                "expected_status_code": "403/404",
                "evidence": evidence,
                "finding_title": finding_title,
                "tested_persona": "USER_B (Unauthorized Tenant)",
                "target_resource": "resource-user-a"
            })

        # 2. BFLA Check: Accessing administrative endpoint with unprivileged or unauthenticated persona
        if is_bfla_cand:
            target_url = f"{base_url.rstrip('/')}/{path.lstrip('/')}"

            # Probe with standard User A
            headers = {"User-Agent": "ASE-AuthAudit/1.0"}
            if user_a_token:
                headers["Authorization"] = f"Bearer {user_a_token}"

            probe = execute_auth_probe(target_url, method, headers)
            obs_code = probe["status_code"]

            if obs_code in (200, 201, 204):
                status = "VULNERABLE"
                finding_title = f"BFLA: Administrative function accessible to standard role on {method} {path}"
                evidence = f"Standard user accessed privileged function and received HTTP {obs_code}. Expected 403 Forbidden."
            elif obs_code in (401, 403):
                status = "SECURE"
                finding_title = None
                evidence = f"Access properly restricted with HTTP {obs_code}."
            elif obs_code is None:
                status = "INCONCLUSIVE"
                finding_title = None
                evidence = f"Probe failed or timed out: {probe['error']}"
            else:
                status = "INCONCLUSIVE"
                finding_title = None
                evidence = f"Received unexpected status code HTTP {obs_code}."

            results.append({
                "test_type": "BFLA",
                "endpoint": path,
                "method": method,
                "status": status,
                "observed_status_code": obs_code,
                "expected_status_code": "403",
                "evidence": evidence,
                "finding_title": finding_title,
                "tested_persona": "USER_A (Non-Admin Standard User)"
            })

    vulnerabilities = [r for r in results if r["status"] == "VULNERABLE"]
    return {
        "target_base_url": base_url,
        "tested_endpoints_count": len(results),
        "vulnerable_count": len(vulnerabilities),
        "secure_count": sum(1 for r in results if r["status"] == "SECURE"),
        "inconclusive_count": sum(1 for r in results if r["status"] == "INCONCLUSIVE"),
        "results": results,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "limitations": [
            "Synthetic users test token-based RBAC/BOLA rules.",
            "Complex multi-step or stateful workflows require custom scenario testing.",
            "Credentials and tokens are redacted in all output evidence."
        ]
    }
